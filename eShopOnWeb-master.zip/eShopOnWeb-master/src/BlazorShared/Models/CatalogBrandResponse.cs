﻿using System.Collections.Generic;

namespace BlazorShared.Models
{
    public class CatalogBrandResponse
    {
        public List<CatalogBrand> CatalogBrands { get; set; } = new List<CatalogBrand>();
    }
}
