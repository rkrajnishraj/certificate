﻿namespace BlazorShared.Models
{
    public class CatalogType : LookupData
    {
    }
}
